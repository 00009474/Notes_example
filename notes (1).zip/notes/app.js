const express = require('express')
const app = express()
const fs = require('fs')

let notesDb = []

fs.readFile('./data/notes.json', (err, data) => {
	if (!err) {
		notesDb = JSON.parse(data)
	}
})

const parser = require('body-parser')
app.use(parser.urlencoded({extended: true}))

app.use('/assets', express.static('./public'))

app.set('view engine', 'pug')

app.get('/', (req, res) => {
	res.render('index')
})

app.get('/notes/create', (req, res) => {
	res.render('create', {show: req.query.success})
})

function generateRandomId() {
	return Math.floor(Math.random() * 99999999999) + 1;
}

app.post('/notes/create', (req, res) => {
	// get the sent data
	const note = {
		id: generateRandomId(),
		title: req.body.title,
		body: req.body.details
	}

	// store it somewhere
	notesDb.push(note)
	fs.writeFile('./data/notes.json', JSON.stringify(notesDb), (err) => {
		if (err) {
			res.redirect('/notes/create?success=0')
		} else {
			res.redirect('/notes/create?success=1')
		}
	})

	// redirect user back
	
})

app.get('/notes', (req, res) => {
	res.render('notes', {notes: notesDb})
})

app.get('/notes/:id', (req, res) => {
	const id = parseInt(req.params.id)
	const note = notesDb.find(note => note.id === id)

	res.render('note', {note: note})
})

app.get('/notes/:id/delete', (req, res) => {
	const id = parseInt(req.params.id)
	const index = notesDb.findIndex(note => note.id === id)

	// Delete from notesDB array
	notesDb.splice(index, 1)

	// Update notes.json file
	fs.writeFile('./data/notes.json', JSON.stringify(notesDb), (err) => {
		if (err) {
			res.redirect('/notes?success=0')
		} else {
			res.redirect('/notes?success=1')
		}
	})
})

app.get('/notes/:id/archive', (req, res) => {
	const id = parseInt(req.params.id)
	const index = notesDb.findIndex(note => note.id === id)


	notesDb[index].archived = true

	fs.writeFile('./data/notes.json', JSON.stringify(notesDb), (err) => {
		if (err) {
			res.redirect('/notes/'+id+'?success=0')
		} else {
			res.redirect('/notes/'+id+'?success=1')
		}
	})
})

app.get('/archive', (req, res) => {
	const notes = notesDb.filter(note => note.archived)

	res.render('archive', {notes: notes})
})

app.listen(8080, () => console.log('App is running...'))
